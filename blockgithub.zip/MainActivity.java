package com.newblockblast.ironsmash; // Paket adını projenle uyumlu yap

import android.os.Bundle;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class MainActivity extends AppCompatActivity {

    private InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. AdMob SDK Başlatma
        MobileAds.initialize(this, initializationStatus -> {});

        // 2. Banner Reklamı (Alt Kısım)
        AdView adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId("ca-app-pub-3498906520872394/2142602397"); // Senin Banner ID'n

        // Tasarımdaki reklam alanını bul ve reklamı ekle
        LinearLayout adContainer = findViewById(R.id.reklam_alani);
        if (adContainer != null) {
            adContainer.addView(adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            adView.loadAd(adRequest);
        }

        // 3. Geçiş Reklamını Yükle (Tam Ekran)
        AdRequest interstitialRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, "ca-app-pub-3498906520872394/2862785562", interstitialRequest,
            new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    mInterstitialAd = interstitialAd;
                    // TEST İÇİN: Reklam yüklenince otomatik gösterir. 
                    // İstersen bu satırı silip reklamGoster() metodunu kullanabilirsin.
                    mInterstitialAd.show(MainActivity.this);
                }
            });
    }

    // Bu metodu oyun bittiğinde veya butona tıklandığında çağırabilirsin
    public void reklamGoster() {
        if (mInterstitialAd != null) {
            mInterstitialAd.show(this);
        }
    }
}
