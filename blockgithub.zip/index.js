document.addEventListener('deviceready', async () => {
    await admob.start();
    
    // Banner Reklamı Göster
    const banner = new admob.BannerAd({
        adUnitId: 'ca-app-pub-3498906520872394/2142602397',
    });
    await banner.show();
}, false);
